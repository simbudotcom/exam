<?php
/*PHP Login and registration script Version 1.0, Created by Gautam, www.w3schools.in*/
error_reporting(0);
//require('config.php');
//require('dabasecon.php');

//require('student_functions.php');
require_once('student_header.php');
/*Check for authentication otherwise user will be redirects to main.php page.*/
if (!isset($_SESSION['UserData'])) {
    exit(header("location:student_main.php"));
}


?>
<?php
//echo '<pre>';
date_default_timezone_set('Asia/Kolkata');
$data=get_student_data($con, $_SESSION['UserData']['id'], true);
$hname=$data['name'];
$regno=$data['regno'];
$course_code=$data['course_code'];
$course_name = $data['course_name'];
$session_year=$data['session_year'];
//echo '</pre>';
//
if ($hname=='') {
  
    exit(header("location:logout.php"));
}
if ($user_type=='admin') {
  
    exit(header("location:index.php"));
}

?>
<?php
//echo '<pre>';
date_default_timezone_set('Asia/Kolkata');
?>
  
<style type="text/css">
  table tr,td {
    vertical-align: top;
  }
      #invoice {
        width: 800px;
        height: 1100px;

      }
   
</style>
<style type="text/css">
    #intro1 {
  width: 100%;
  height: 13vh;
  background: linear-gradient(45deg, rgba(29, 224, 153, 0.8), rgba(29, 200, 205, 0.8)), url("../img/intro-bg.jpg") center top no-repeat;
  background-size: cover;
  position: relative;
}

</style>
<!-- container -->
<section id="intro1"></section>   
<section id="about1" class="section-bg">
   <div class="container">   
       <?php 
       include 'stud_menu.php'; 
       ?>

 <div class="row">
  
        
      <div class="table_content table-responsive">
<div align="center">
      <div class="card-body"><center> <button type="button" class="btn btn-success px-4" onclick="printDiv('invoice')"><span class="fa fa-print mr-2"></span>Print</button></center>
     <div id="invoice" style="
        
        background-repeat: no-repeat;
        background-size: 100%;">
        
         <div class="table_content table-responsive"><center>
   <table border="0">
        <tr><td><img src="assets/img/banner.png" width="750px" height="150px"></td></tr>
        <tr><td><center><h2 style="color: red"><u>University Departments</u></h2></center></td></tr>
        <tr><td><center><h4 style="color: blue">April - 2021 <br> (Online Examinations)</h4><br><h5 style="color: green"><u>e-Hall Ticket</u></h5></center></td></tr>
      </table>
        
     

      <table border="0" class="table table-striped">
        <tr>
            
            <td width="200px">Name of the Candidate </td>
           
            <td width="400px"><?php print $hname; ?></td>
        </tr>
        <tr>
            
            <td width="200px">Register Number </td>
           
            <td width="400px"><?php print $regno; ?> </td>
        </tr>
        <tr>
           
            <td width="200px">Course Code  </td>
           
            <td width="400px"><?php  print $course_code; ?></td>
        </tr>
        <tr>
           

               
            <td width="200px">Name of the Programme </td>
          
             <td width="400px"><?php
                          
                
                 print $course_name; 
                 ?>
             </td>
         </tr>
  
    

 
</table>
</center>
<h4 style="color: red;text-align: left">Subject(s) Appearing  </h4>
<center>
  
      <table border="1" class="table">
        <tr>  <th width="150px" style="background-color: #7b7878;"><b style="color:white;"><center>Subject Code </center></b>  </th>
           <th width="500px" style="background-color: #7b7878;"><b style="color:white;"><center>Subject Name</center> </b></th>
          <th width="250px" style="background-color: #7b7878;"><b style="color:white;"><center>Date and Time </center></b> </th></tr>
            <tr>
   <?php
   $slno=1;   
    $sql1q = "SELECT * from `student_online_data` where regno='$regno' group by `subject_code` order by `id` asc "; 
                 $exe1q = mysqli_query($con,$sql1q) or die(mysql_error());
                 //echo $sql1;
                 while($row1q = mysqli_fetch_array($exe1q))
                {
                  $subject_code1=$row1q['subject_code'];

              
               $sql1 = "SELECT * from `subjects` where `session_year`='$session_year' and `subject_code`='$subject_code1' order by `subject_code`  asc limit 1"; 
                 $exe1 = mysqli_query($con,$sql1) or die(mysql_error());
                 //echo $sql1;
                  if(mysqli_num_rows($exe1)>0){
                 $row1 = mysqli_fetch_array($exe1);
                
                   
         $subject_code=$row1['subject_code'];
        $subject_name=$row1['subject_name'];
        $exam_date=$row1['exam_date'];
       
?>      
          
           
          
            
           
           
            <td><?php print $subject_code;?></td>
       
              <td><?php print  $subject_name;?></td>
           
           
              <td><?php date_default_timezone_set('Asia/Kolkata'); $cur_date=date('Y-m-d H:i:s'); $date1=date('d-m-Y h:i:sa', strtotime($exam_date)); if($date1!='01-01-1970 05:30:00am'){  print $date1; } else { print '<center>'.'-----'.'</center>'; } ?></td>
        </tr>


  <?php

   } 
 }
   ?>
</table>
</center>
<h4 style="color: red;text-align: left"><u> Instructions: </u></h4>
<p style="text-align: left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Visit <a href="https://www.alagappauniversity.ac.in/reg_time_inst.php">www.alagappauniversity.ac.in</a></p>

<table>
  <tr>
    <td width="500px"></td><td><center><img src="assets/img/coe.png" width="200px" height="100px"><br>E.KANNAPIRAN<br>Controller of Examinations <span>(i/c)</span></center></td></tr>
</table>
</div>



</div><br><center> <button type="button" class="btn btn-success px-4" onclick="printDiv('invoice')"><span class="fa fa-print mr-2"></span>Print </button></center></div></div></div></div></div></selection>
<!-- /container -->
<?php 
require('footer_new.php');
?>
<script type="text/javascript">
        function printDiv(divName) {
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;

            document.body.innerHTML = printContents;

            window.print();

            document.body.innerHTML = originalContents;
        }
    </script>