<?php
       include 'header.php';
       ?>
          <section id="about" class="about" style="padding-top: 120px">
      <div class="container">
        <div class="row">
          <!-- <div class="col-lg-6 order-1 order-lg-2" data-aos="zoom-in" data-aos-delay="150">
            <img src="assets/img/about.jpg" class="img-fluid" alt="">
          </div> -->
          
            <h4>Important Instructions/<br>முக்கிய வழிமுறைகள்</h4>
            <p class="font-italic">
              Before Starting your Exam you must read and follow the following instruction carefully. /தேர்வைத் தொடங்குவதற்கு முன் பின்வரும் வழிமுறைகளை கவனமாகப் படித்து பின்பற்ற வேண்டும்.
            </p>
            <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content" data-aos="fade-right">
            <ul>
              <li><i class="icofont-check-circled"></i> User ID and password to login the University online examination portal will be the register number and date of birth of student respectively</li>
              <li><i class="icofont-check-circled"></i> Students facing login problems shall be informed to send image of ID card to the following email onlineexamcoe@gmail.com and Whats App Mobile Number
9489079099.</li>

         
              <li><i class="icofont-check-circled"></i> Students shall write their exam on A-4 size unruled paper in their own hand writing and the total number of pages should not exceed 40 </li>
              <li><i class="icofont-check-circled"></i> The candidate has to write his/her register number (both top and bottom of answer script), page number and affix the signature in every page</li>
              <li><i class="icofont-check-circled"></i> The total number of pages written should be mentioned in the front page of answer script</li>
            
                <li><i class="icofont-check-circled"></i> Candidates found guilty of using unfair means of any nature shall be liable for disciplinary action.</li>
            </ul>
           <!--  <a href="#" class="read-more">Read More <i class="icofont-long-arrow-right"></i></a> -->

          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content" data-aos="fade-right">
            <ul>
              <li><i class="icofont-check-circled"></i> online examination portal உள்ளே செல்ல தங்களது பதிவு எண் மற்றும் பிறந்த தேதியினை பயன்படுத்தவும் </li>
              <li><i class="icofont-check-circled"></i> login செய்வதில் ஏதேனும் இடர்பாடு ஏற்பட்டால் உடனடியாக தங்களது பல்கலைக்கழக / கல்லூரியால் வழங்கப்பட்ட அடையாள அட்டையை இருபுறமும் photo எடுத்து   onlineexamcoe@gmail.com என்ற email  முகவரிக்கு அல்லது 9489079099 என்ற whatsapp எண்ணிற்கு அனுப்பவும்.</li>

              <li><i class="icofont-check-circled"></i> மாணவர்கள் கண்டிப்பாக A4  unruled  பேப்பர் மட்டுமே பயன்படுத்த வேண்டும் அதிகபட்சம் 40 பக்கங்கள்   மட்டுமே  எழுத வேண்டும்   </li>
              <li><i class="icofont-check-circled"></i> மாணவர்கள் கண்டிப்பாக விடைத்தாளின் மேல்புறம் மற்றும் கீழ்ப்புறத்தில் பதிவு எண், பக்க எண் மற்றும் கையொப்பம் இட  வேண்டும் </li>
              <li><i class="icofont-check-circled"></i> மொத்தம் எழுதிய பக்கங்கள் எத்தனை என்பதை முதல் பக்கத்தில் எழுத  வேண்டும் </li>
             
              <li><i class="icofont-check-circled"></i> தேர்வு முறைகேடுகளில் ஈடுபடுவோர் மீது தக்க நடவடிக்கை எடுக்கப்படும்  </li>
            </ul>
           <!--  <a href="#" class="read-more">Read More <i class="icofont-long-arrow-right"></i></a> -->

          </div>
        </div>
<br><br><br><br>
      </div>
   <?php
       include 'footer.php';
       ?>