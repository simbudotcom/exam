<?php
error_reporting(1);
session_unset();
session_destroy();
require_once('config.php');
require('student_header.php');
?>

<style>
  .main-login{
    
   padding-top: 150px;
    width: 450px;
  }
  form#student_login_form {
       background-color: rgba(0, 123, 255, .25);
       padding: 50px;
      border-radius: 10px;

}
input#Email {
    margin-bottom: 24px;
}
button#button-main{
   margin-top: 24px;
   border: none;
}
h3.form-signin-heading{
  color: #8e33f6;
  font-weight: bold;  
}
</style>



  <section class="banner-area1">
    <div class="container">
      <div class="row justify-content-center align-items-center">

<!-- Login Form -->

<!-- HTML Form -->
<div class="main-login">
      <form action="student_submit.php" method="post" name="student_login_form" id="student_login_form" autocomplete="off">
        <h3 class="form-signin-heading" style="font-size: 25px">Student Login / <br>மாணவர் உள்நுழைவு</h3>
<br>
         <label style="color: #012109;">Register Number / பதிவு எண்<span style="color: red">*</span></label>
        <input type="text" name="regno" id="regno" class="form-control" placeholder="Enter Your Register Number" required autofocus><br>

         <label style="color: #012109;">Date of Birth (dd-mm-yyyy) Format / பிறந்த தேதி (dd-mm-yyyy) வடிவம்<span style="color: red">*</span></label>
        <input type="text" data-inputmask-alias="dd-mm-yyyy" inputmode="numeric" data-inputmask-inputformat="dd-mm-yyyy" name="dob" id="dob" class="form-control" required="required" placeholder="dd-mm-yyyy"> 
       <br> <img src="captcha_code_file.php?rand=<?php echo rand(); ?>" 
id="captchaimg" ><br>
<label style="color: blue">Enter the above code here :</label>
<input type="text" id="6_letters_code" name="6_letters_code" class="form-control" required>
        <div id="display_error" style="color: #FFFFFF!important;background-color: red; border: none;"></div>

       <button id="button-main" type="submit" class="btn btn-lg btn-primary btn-block">Login / உள்நுழை</button>
      </form><br><br><br>
<!-- /HTML Form -->
</div>



    </div></div></section>


<?php
require('student_footer.php');
?>
<script type="text/javascript">
  $("#dob").inputmask({
               "onincomplete": function () {
                   $(this).addClass('alert alert-danger');
                   $("#dob").val('');
                   $("#display_error").html('Enter Correct Date of Birth');
               },
               "oncomplete": function () {
                   $(this).removeClass('alert alert-danger');
                   $("#display_error").html('');
               }
           });
</script>