<?php
if((empty($_SERVER['HTTP_X_REQUESTED_WITH']) or strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') or empty($_POST)){/*Detect AJAX and POST request*/
  exit("Unauthorized Acces");
}
require_once('config.php');
require('student_functions.php');

/* Check Login form submitted */
if(!empty($_POST) && $_POST['Action']=='student_login_form'){
    /* Define return | here result is used to return user data and error for error message */
    $Return = array('result'=>array(), 'error'=>'');

    $regno = safe_input($con, $_POST['regno']);
   $dob1 = safe_input($con, $_POST['dob']);
   $dob = date("Y-m-d", strtotime($dob1));


    /* Server side PHP input validation */
    if($regno=== '') {
        $Return['error'] = "Please enter Register Number.";
     }
       elseif($dob===''){
        $Return['error'] = "Please enter Date of Birth.";
    }
    if($Return['error']!=''){
        output($Return);
    }

    /* Check Email and Password existence in DB */
    //echo "SELECT * FROM hostel WHERE regno='$regno' AND dob='$dob' LIMIT 1";
    //die();
    $result = mysqli_query($con, "SELECT * FROM student WHERE regno='$regno' AND dob='$dob' LIMIT 1");


    if(mysqli_num_rows($result)==1){
        $row = mysqli_fetch_assoc($result);
        /* Success: Set session variables and redirect to Protected page */
        $Return['result'] = $_SESSION['UserData'] = array('id'=>$row['regno']);
       // recordEvent('student_login', $regno);
           } else {
        /* Unsuccessful attempt: Set error message */
        $Return['error'] = 'Invalid Register number (or) Date of Birth. / தங்களது பதிவு எண் (அ) பிறந்த தேதி தவறாக உள்ளது ';
    }
    /*Return*/
    output($Return);
}


?>