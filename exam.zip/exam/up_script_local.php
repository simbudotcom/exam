<?php
//session_start();
error_reporting(0);
require_once('config.php');
//require('../common/index.php');
//require('student_functions.php');
require('student_header.php');
date_default_timezone_set('Asia/Kolkata');
$now=date('Y-m-d H:i:s');
$data=get_student_data($con, $_SESSION['UserData']['id']);
$hname=$data['name'];
$regno=$data['regno'];
$course_code=$data['course_code'];
$session_year=$data['session_year'];
$subid= $_GET['subid'];
$subject_code=base64_decode($subid); 
$count1=0;
$sql111 = "SELECT * from `subjects` where `subject_code`='$subject_code'"; 
                 $exe111 = mysqli_query($con,$sql111) or die(mysql_error());
              //$row1 = mysqli_fetch_array($exe1);
              //echo $sql1;
                 while($row111 = mysqli_fetch_array($exe111))
                {
                  $count1=$count1+1;
                }

if($count1==0)
{
 echo ("<script language='JavaScript'>
          window.alert('Your URL was Wrong. Kindly reclick the examination answer script uploading button / தங்களது வலைத்தள முகவரி  தவறாக உள்ளது தயவுசெய்து மீண்டும் முயற்சிக்கவும் ');
          window.location.href='student_view_exam.php';
       </script>"); 
}



if (!isset($_SESSION['UserData'])) {
    exit(header("location:student_main.php"));
}



$count=0;
$sql1 = "SELECT * from `uploads_scripts` where `regno`='$regno' and `subject_code`='$subject_code'"; 
                 $exe1 = mysqli_query($con,$sql1) or die(mysql_error());
              //$row1 = mysqli_fetch_array($exe1);
              //echo $sql1;
                 while($row1 = mysqli_fetch_array($exe1))
                {
                  $count=$count+1;
                }

if($count>0)
{
 echo ("<script language='JavaScript'>
          window.alert('Already Uploaded Your Examination script. Thank You');
          window.location.href='student_login.php';
       </script>"); 
}


?>

<?php 
if(isset($_POST["submit"]))
{
$tar_dir="script_UpLoads/";
//$file_name=strtotime(date("Y-m-d H:i:s")).rand(1111,9999);
$file_name=$course_code."_".$subject_code."_".$regno;
$target_file = basename($_FILES["uploadfile"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
$target_file_url = $tar_dir . $file_name.'.'.$imageFileType;
$file_size = $_FILES['uploaded_file']['size'];
if (($file_size > 104857600)){      
        $message = 'File too large. File must be less than 100 megabytes.'; 
        echo "<script>alert('File too large. File must be less than 100 megabytes.');
        window.location = './student_view_exam.php';
        </script>"; 

    }
if ($_FILES['uploadfile']['type'] != "application/pdf")
{
   echo "<script>alert('Sorry, Kindly Upload a valid PDF File.'); window.location = './student_view_exam.php';</script>";

}
if ($uploadOk == 0) {

     echo "<script>alert('Sorry, your file was not uploaded.'); window.location = './student_view_exam.php';</script>";
} else {
    if (move_uploaded_file($_FILES["uploadfile"]["tmp_name"], $target_file_url)) {

$sql = "INSERT INTO uploads_scripts(regno,course_code,subject_code,session_year,t_file,uploded_time)VALUES ('$regno','$course_code','$subject_code','$session_year','$target_file_url','$now')";
//echo $sql;
//die();
            if (mysqli_query($con, $sql)) {
               $message='Your Examination Script Successfullly Uploaded!...'.'Student Details: Reg. No: '.$regno.' Subject Code: '.$subject_code.' Thank You...';
               echo "<script type='text/javascript'>
                    alert('$message');
                    window.location.href='./student_login.php';
                    </script>" ;
              }

    } else {
           echo "<script>alert('Sorry, there was an error uploading your file.'); window.location = './student_view_exam.php';</script>"; 
    }


}}?>



<style>
  .main-login{
    
   padding-top: 0px;
    width: 850px;
  }
  form#student_login_form123 {
       background-color: rgba(0, 123, 255, .25);
       padding: 50px;
      border-radius: 10px;

}
input#Email {
    margin-bottom: 24px;
}
button#button-main{
   margin-top: 24px;
   border: none;
}
h3.form-signin-heading{
  color: #8e33f6;
  font-weight: bold;  
}
</style>
<section class="page-section mb-0" style="min-height: 530px">
   <div class="container">  
  <br><br><br> <?php include 'stud_menu.php'; ?> 
     <br>
<center>
  <div class="table-responsive">
<div class="main-login">
      <form action="#" method="post" enctype="multipart/form-data"  name="student_login_form" id="student_login_form123">
        <h3 class="form-signin-heading" style="font-size: 25px">Upload Your Answer Script / <br>விடைத்தாள் பதிவேற்றும் இடம் </h3>
<br>
         <label style="color: #012109;">Register Number / பதிவு எண்</label>
        <input type="text" name="regno" id="regno" class="form-control" value="<?php echo $regno; ?>" readonly="readonly"><br>

         <label style="color: #012109;">Name of the Student / மாணவரின் பெயர் </label>
        <input type="text" name="name" id="name" class="form-control" value="<?php echo $hname; ?>" readonly="readonly"> <br><br>
        <label style="color: #012109;">Choose Your Answer Script File / விடைத்தாளை தெரிவு செய்யவும் <br><span style="color: red">* Must be in .PDF file only / pdf மட்டுமே ஏற்றுக்கொள்ளப்படும் </span></label>
        <input type="file" name="uploadfile" id="uploadfile" class="form-control" required="required" accept="application/pdf"> 

        <div id="display_error" style="color: #FFFFFF!important;background-color: red; border: none;"></div>
        <br>
<input type="checkbox" class="forn-control" required="" name="confirmation" />
<label>Confirm submission / பதிவேற்றத்தை உறுதிசெய்க</label>
        <br>
        <input class="btn btn-primary" type="submit" name="submit" value="Upload / பதிவேற்று">
       <!-- <button id="button-main" type="submit" name="submit" class="btn btn-lg btn-primary btn-block">Upload / பதிவேற்று</button> -->
      </form><br><br><br>
<!-- /HTML Form -->
</div>
</div>
</center>

</div></section>   



<!-- /container -->
<?php 
require('student_footer.php');
?>
<link rel="stylesheet" href="./includes/DataTable/datatables.css" type="text/css">
    <link rel="stylesheet" href="./includes/DataTable/datatables.min.css" type="text/css">
    <script src="./includes/DataTable/datatables.js"></script> 
    <script src="./includes/DataTable/datatables.min.js"></script>


<style>
@media only screen and (min-width:768px){
  .home_slider_left{
    width:22%;
    margin:0;
    padding-right:15px;
  }
  .home_slider{
    width:78%;
    margin:0;
  }
  .home_slider_right{
    width:22%;
    margin:0;
    padding-left:28px;

  }
}
</style>


