<?php
/*PHP Login and registration script Version 1.0, Created by Gautam, www.w3schools.in*/
error_reporting(0);
//require_once('config.php');

// require('student_functions.php');
require_once('student_header.php');
/*Check for authentication otherwise user will be redirects to main.php page.*/
if (!isset($_SESSION['UserData'])) {
    exit(header("location:student_main.php"));
}


?>
<?php
if ($user_type=='admin') {
  
    exit(header("location:index.php"));
}

?>
<section class="page-section mb-0" style="min-height: 530px">
   <div class="container">  
  <br><br> <?php include 'stud_menu.php'; ?> 
     <br><br>

 <div class="row justify-content-center align-items-center">
           
      <div class="table_content table-responsive">

      <table border="0" class="table table-striped">
  
        <tr>
            
          
            <td width="500px"><a href="https://pdfcandy.com/jpg-to-pdf.html" target="_blank">Click Here: Option Link 1 (for Converting JPG to PDF) / விருப்பம் 1 (இணையவழி JPG TO PDF மாற்ற இங்கே கிளிக் செய்யவும்)</td>
        </tr>
        <tr>
            
           
             <td width="500px"><a href="https://www.convert-jpg-to-pdf.net/" target="_blank"> Click Here: Option Link 2 (for Converting JPG to PDF) / விருப்பம் 2  (இணையவழி JPG TO PDF மாற்ற இங்கே கிளிக் செய்யவும்)</td>
        </tr>
       
</table><br><br> <br><br> <br><br> 
</div></div>
</div></section>
<!-- /container -->
<?php 
require('student_footer.php');
?>
