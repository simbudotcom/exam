<?php
session_start(); /* Session */
$path='localhost';
$con=mysqli_connect("localhost","root","admin","coe_exam_up"); /*Database Connection*/
?>
