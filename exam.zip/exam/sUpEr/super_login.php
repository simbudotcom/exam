<?php
/*PHP Login and registration script Version 1.0, Created by Gautam, www.w3schools.in*/
error_reporting(0);
// require('dabasecon.php');
require_once('config.php');
require('super_functions.php');
/*Check for authentication otherwise user will be redirects to main.php page.*/
if (!isset($_SESSION['UserData'])) {
    exit(header("location:super_main.php"));
}
require('super_header.php');
?>
<?php
//echo '<pre>';
  // print_r(get_govt_user_data($con, $_SESSION['UserData']['user_id']));
//die();
$hname='';
$data=get_super_user_data($con, $_SESSION['UserData']['user_id']);
$hname=$data['email'];
$dept=$data['dept'];
$category=$data['category'];
//echo '</pre>';
//
if ($category!='admin') {
  
    exit(header("location:super_main.php"));
}
?>
    

<section class="page-section mb-0" style="min-height: 570px">
   <div class="container">   
    <br><br> <br><br><br><br> <br>
      <div id="introCarousel" class="carousel  slide carousel-fade" data-ride="carousel">
<!-- container -->


</div>
      <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
            <!-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> -->
          </div>

          <!-- Content Row -->
          <div class="row">

            <!-- Earnings (Monthly) Card Example -->
            
            <!-- Earnings (Monthly) Card Example -->
            

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-3 mb-4">
              <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Number of Subjects</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                       10

                        
                      </div>
                                          
                        </div>
                      </div>
                    </div>
                    <!-- <div class="col-auto">
                      <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                    </div> -->
                  </div>
                </div>
              

            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-3 mb-4">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                 <a href="bed_questions.php">   <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">B.Ed., Total No. Questions</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        <?php $abc1="SELECT COUNT(*) AS `pre_live_count1` FROM `bed_question` ";
$result1=mysqli_query($con,$abc1);
if($result1)
 {
    while($row1=mysqli_fetch_assoc($result1))
  {
        $livetotal1=$row1['pre_live_count1'];
        echo $row1['pre_live_count1'];
  }     
 }

                          ?>
                      </div>
                                          
                        </div></a>
                  
                  </div>
                </div>
              </div>
            </div>
             <div class="col-xl-3 col-md-3 mb-4">
              <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                   <a href="mca_questions.php">  <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">MCA., Total No. Questions </div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                         <?php $abc1="SELECT COUNT(*) AS `pre_live_count1` FROM `mca_question` ";
$result1=mysqli_query($con,$abc1);
if($result1)
 {
    while($row1=mysqli_fetch_assoc($result1))
  {
        $livetotal1=$row1['pre_live_count1'];
        echo $row1['pre_live_count1'];
  }     
 }

                          ?>
                      </div>
                                          
                        </div></a>
                      </div>
                    </div>
                    <!-- <div class="col-auto">
                      <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                    </div> -->
                  </div>
                </div>
              

            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-3 mb-4">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                   <a href="mba_questions.php">  <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">MBA., Total No. Questions </div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                       <?php $abc1="SELECT COUNT(*) AS `pre_live_count1` FROM `mba_question` ";
$result1=mysqli_query($con,$abc1);
if($result1)
 {
    while($row1=mysqli_fetch_assoc($result1))
  {
        $livetotal1=$row1['pre_live_count1'];
        echo $row1['pre_live_count1'];
  }     
 }

                          ?> 
                      </div>
                                          
                        </div></a>
                  
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Content Row -->
<div class="row">

            <!-- Earnings (Monthly) Card Example -->
            
            <!-- Earnings (Monthly) Card Example -->
            

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-3 mb-4">
              <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <a href="bio_questions.php"> <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Biology Total No. Questions</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        <?php $abc1="SELECT COUNT(*) AS `pre_live_count1` FROM `bio_question` ";
$result1=mysqli_query($con,$abc1);
if($result1)
 {
    while($row1=mysqli_fetch_assoc($result1))
  {
        $livetotal1=$row1['pre_live_count1'];
        echo $row1['pre_live_count1'];
  }     
 }

                          ?>
                        
                      </div>
                                          
                        </div></a>
                      </div>
                    </div>
                    <!-- <div class="col-auto">
                      <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                    </div> -->
                  </div>
                </div>
              

            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-3 mb-4">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <a href="bios_questions.php"> <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Biological Science Total No. Questions</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        <?php $abc1="SELECT COUNT(*) AS `pre_live_count1` FROM `bios_question` ";
$result1=mysqli_query($con,$abc1);
if($result1)
 {
    while($row1=mysqli_fetch_assoc($result1))
  {
        $livetotal1=$row1['pre_live_count1'];
        echo $row1['pre_live_count1'];
  }     
 }

                          ?>
                      </div>
                                          
                        </div></a>
                  
                  </div>
                </div>
              </div>
            </div>
             <div class="col-xl-3 col-md-3 mb-4">
              <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <a href="cat_questions.php"> <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Catering Total No. Questions </div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                         <?php $abc1="SELECT COUNT(*) AS `pre_live_count1` FROM `cat_question` ";
$result1=mysqli_query($con,$abc1);
if($result1)
 {
    while($row1=mysqli_fetch_assoc($result1))
  {
        $livetotal1=$row1['pre_live_count1'];
        echo $row1['pre_live_count1'];
  }     
 }

                          ?>
                      </div>
                                          
                        </div></a>
                      </div>
                    </div>
                    <!-- <div class="col-auto">
                      <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                    </div> -->
                  </div>
                </div>
              

            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-3 mb-4">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                   <a href="che_questions.php">  <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Chemistry Total No. Questions </div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                       <?php $abc1="SELECT COUNT(*) AS `pre_live_count1` FROM `che_question` ";
$result1=mysqli_query($con,$abc1);
if($result1)
 {
    while($row1=mysqli_fetch_assoc($result1))
  {
        $livetotal1=$row1['pre_live_count1'];
        echo $row1['pre_live_count1'];
  }     
 }

                          ?> 
                      </div>
                                          
                        </div></a>
                  
                  </div>
                </div>
              </div>
            </div>
          </div>
          

          <!-- Content Row -->
 <div class="row">

            <!-- Earnings (Monthly) Card Example -->
            
            <!-- Earnings (Monthly) Card Example -->
            

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-3 mb-4">
              <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                   <a href="mat_questions.php">  <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Mathematics Total No. Questions</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        <?php $abc1="SELECT COUNT(*) AS `pre_live_count1` FROM `mat_question` ";
$result1=mysqli_query($con,$abc1);
if($result1)
 {
    while($row1=mysqli_fetch_assoc($result1))
  {
        $livetotal1=$row1['pre_live_count1'];
        echo $row1['pre_live_count1'];
  }     
 }

                          ?>
                        
                      </div>
                                          
                        </div></a>
                      </div>
                    </div>
                    <!-- <div class="col-auto">
                      <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                    </div> -->
                  </div>
                </div>
              

            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-3 mb-4">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <a href="mic_questions.php"> <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Microbiology Science Total No. Questions</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        <?php $abc1="SELECT COUNT(*) AS `pre_live_count1` FROM `mic_question` ";
$result1=mysqli_query($con,$abc1);
if($result1)
 {
    while($row1=mysqli_fetch_assoc($result1))
  {
        $livetotal1=$row1['pre_live_count1'];
        echo $row1['pre_live_count1'];
  }     
 }

                          ?>
                      </div>
                                          
                        </div></a>
                  
                  </div>
                </div>
              </div>
            </div>
             <div class="col-xl-3 col-md-3 mb-4">
              <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                   <a href="phy_questions.php">  <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Physics Total No. Questions </div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                         <?php $abc1="SELECT COUNT(*) AS `pre_live_count1` FROM `phy_question` ";
$result1=mysqli_query($con,$abc1);
if($result1)
 {
    while($row1=mysqli_fetch_assoc($result1))
  {
        $livetotal1=$row1['pre_live_count1'];
        echo $row1['pre_live_count1'];
  }     
 }

                          ?>
                      </div>
                                          
                        </div></a>
                      </div>
                    </div>
                    <!-- <div class="col-auto">
                      <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                    </div> -->
                  </div>
                </div>
              

            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-3 mb-4">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1"></div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                       
                      </div>
                                          
                        </div>
                  
                  </div>
                </div>
              </div>
            </div>
          </div>
                  

        </div>
      </div>
    </div>
  </section>
  </body>
</html>
<?php
include('super_footer.php');
//echo "hai";
?>
<link rel="stylesheet" href="./includes/DataTable/datatables.css" type="text/css">
    <link rel="stylesheet" href="./includes/DataTable/datatables.min.css" type="text/css">
    <script src="./includes/DataTable/datatables.js"></script> 
    <script src="./includes/DataTable/datatables.min.js"></script> 
<script>
/*$(document).ready( function () {
    $('#myTable').DataTable();
} );*/
$(document).ready(function() {
    var printCounter = 0;
 
    // Append a caption to the table before the DataTables initialisation
   // $('#view_stock').append('<caption style="caption-side: bottom">Stock List View.</caption>');
 
    $('#myTable').DataTable( {
        dom: 'Bfrtip',
        scrollX:'true',
        buttons: [
            'copy',
            {
                extend: 'excel',
                messageTop: ''
            },
            {
                extend: 'pdf',
                orientation:'landscape',
                messageBottom: null
            },
            {
                extend: 'print',
                messageTop: function () {
                    printCounter++;
 
                    if ( printCounter === 1 ) {
                        return 'This is the first time you have printed this document.';
                    }
                    else {
                        return 'You have printed this document '+printCounter+' times';
                    }
                },
                messageBottom: null
            }
        ]
    } );
} );
</script>

<style>
@media only screen and (min-width:768px){
  .home_slider_left{
    width:22%;
    margin:0;
    padding-right:15px;
  }
  .home_slider{
    width:78%;
    margin:0;
  }
  .home_slider_right{
    width:22%;
    margin:0;
    padding-left:28px;

  }
}
</style>





