<?php
if((empty($_SERVER['HTTP_X_REQUESTED_WITH']) or strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') or empty($_POST)){/*Detect AJAX and POST request*/
  exit("Unauthorized Acces");
}
require('config.php');
require('super_functions.php');

/* Check Login form submitted */
if(!empty($_POST) && $_POST['Action']=='super_login_form'){
    /* Define return | here result is used to return user data and error for error message */
    $Return = array('result'=>array(), 'error'=>'');

    $email = safe_input($con, $_POST['Email']);
    $password1 = safe_input($con, $_POST['Password']);
$password = md5($password1);
    /* Server side PHP input validation */
    if($email=== '') {
        $Return['error'] = "Please enter User Name.";
    }elseif($password===''){
        $Return['error'] = "Please enter Password.";
    }
    if($Return['error']!=''){
        output($Return);
    }

    /* Check Email and Password existence in DB */
   $query = "SELECT * FROM super_users WHERE email = ? AND password = ?";
        $stmt = $con->prepare($query);
        $stmt->bind_param("ss", $email, $password);
        $stmt->execute();
        $result = $stmt->get_result();
        //$row  = mysqli_fetch_array($result);
    //$result = mysqli_query($con, "SELECT * FROM swayam_users WHERE email='$email' AND password='".md5($password)."' LIMIT 1");
    if(mysqli_num_rows($result)==1){
        $row = mysqli_fetch_assoc($result);
        /* Success: Set session variables and redirect to Protected page */
        unset($_SESSION['UserData']);
        $Return['result'] = $_SESSION['UserData'] = array('user_id'=>$row['user_id']);
    } else {
        /* Unsuccessful attempt: Set error message */
        $Return['error'] = 'Invalid Login Credential.';
    }
    /*Return*/
    output($Return);
}




?>