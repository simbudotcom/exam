<?php
/*PHP Login and registration script Version 1.0, Created by Gautam, www.w3schools.in*/
error_reporting(0);
require('config.php');

require('student_functions.php');

/*Check for authentication otherwise user will be redirects to main.php page.*/
if (!isset($_SESSION['UserData'])) {
    exit(header("location:student_main.php"));
}

require('student_header.php');
?>
<?php
//echo '<pre>';
date_default_timezone_set('Asia/Kolkata');
$data=get_student_data($con, $_SESSION['UserData']['id']);
$hname=$data['name'];
$regno=$data['regno'];
$course_code=$data['course_code'];
$session_year=$data['session_year'];
//echo '</pre>';
//
if ($user_type=='admin') {
  
    exit(header("location:index.php"));
}

?>
<style type="text/css">
  @media print{
    .close_icon{
      display: none;
    }
  }
  .close_icon{
            background: red;
    color: white;
    padding: 12px 18px;
    border-radius: 4px;
    font-size: 30px;
  /*opacity:0;*/
float: right;
margin:0;padding:0;
  }
  #image-holder:hover .close_icon{
    opacity: 1;
  }
</style>
<section class="page-section mb-0" style="min-height: 530px">
   <div class="container">  
  <br><br> 
  <?php include 'stud_menu.php'; ?> 
     <br><br>


 <div class="row text-center ">
  
  <div class="col-12 " style="overflow: auto; ">

  <table>   

      <div class="card-body">
         <button class="btn btn-success" onclick="$('#fileUpload').click();">
           
<i class='bx bx-right-arrow bx-fade-right'></i>&nbsp;&nbsp;&nbsp;Click here to add your answer script image from camera or captured answer scripts one by one or group select to convert and download images to PDF /  செல்போன் மூலமாக PHOTO எடுத்து இணைக்க (அல்லது) முன்னதாகவே  PHOTO எடுத்து வைத்துள்ள விடைத்தாள்களை ஒன்றன் பின் ஒன்றாக அல்லது மொத்தமாக SELECT செய்து PDF ஆக மாற்றி பதிவிறக்கம் செய்ய இங்கே கிளிக் செய்யவும்  
 &nbsp;&nbsp;&nbsp; <i class='bx bx-left-arrow bx-fade-left'></i>        </button>
        <input id="fileUpload" type="file" multiple class="d-none" />
<div id="image-holder">
  <?php
                             $sql1 = "SELECT * from `student` where `regno`= '$regno'  limit 1"; 
                 $exe1 = mysqli_query($con,$sql1) or die(mysql_error());
                 //echo $sql1;
                 while($row1 = mysqli_fetch_array($exe1))
                {
                   
        ?>
        
        <img src="./assets/img/script_header.png" style="width: 100%"><br><br><h4 class="text-center"><u>Online Examinations</u></h4>
        <div style="width: 730px;" class="p-5">
        <div class="text-left" style="border:solid 2px #999;padding: 30px;">
       <p> Name of the Candidate / <br>மாணவரின் பெயர் &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php print $row1['name']; ?></p>
       <p>Register Number / <br>பதிவு எண் &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php print $row1['regno']; ?></p>
       <p>Course Code / <br>பாடநெறி குறியீடு &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php  print $row1['course_code']; ?></p>
       <p>Name of the Programme /<br> பட்டத்தின் பெயர்  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 

<?php
                             $sql12 = "SELECT * from `course` where `course_code`= '$course_code'  limit 1"; 
                 $exe12 = mysqli_query($con,$sql12) or die(mysql_error());
                 //echo $sql1;
                 while($row12 = mysqli_fetch_array($exe12))
                {
                 $course_name=$row12['course_name']; 
                 }
                 print $course_name; 
                 ?>
       </p></div><br><br>  <div id="pagescount" class="text-left" style="border:solid 2px #999;padding: 30px;">
      
  


    

  <?php

  } 
 
   ?>
   <?php
    $slno=1; 
    date_default_timezone_set('Asia/Kolkata');
    $cdate=date('Y-m-d 10:00:00');
               
               $sql1a = "SELECT * from `subjects` where course_code='$course_code' and `session_year`='$session_year' and `exam_date`='$cdate' limit 1"; 
                 $exe1a = mysqli_query($con,$sql1a) or die(mysql_error());
                 //echo $sql1a;
                 while($row1a = mysqli_fetch_array($exe1a))
                {
                   
        $subject_code=$row1a['subject_code'];
        $subject_name=$row1a['subject_name'];
        $exam_date=$row1a['exam_date'];
      }
        

?>
       <p>Subject/Course Code /<br> பாடக் குறியீடு  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php print 'F2287'; ?></p>
       <p>Subject/Course Name /<br>பாடத்தின் பெயர்  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php print 'ENVIRONMENTAL STUDIES'; ?></p>
       <p>Exam Date  /<br>தேர்வு தேதி  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php  print '14-09-2020 10.00 AM'; ?></p>
<p>No. of Pages written  /<br>எழுதிய  பக்கங்களின் <br>எண்ணிக்கை  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="noofpages"></span></p>
</div></div>
           <div style='page-break-after:always'></div>
</div>
        <!-- <div id="invoice" style="
          background-image:url('assets/img/watermark.png');
          background-repeat: no-repeat;
          background-size: 100%;">
 

           <img src="./sample_pdf/7119817-01.jpg" width="730" height="1120">

           <div style='page-break-after:always'></div>

           

        </div> -->
   

</table>
</div>
</div>

<center class="m-5 p-5">
<div class="progress switch_button_progress" style="display: none">
    <div class="progress-bar progress-bar-striped progress-bar-animated" style="width: 100%">Processing</div>
</div>
 <button class="btn btn-danger switch_button" onclick="generatePDF()"><i class='bx bx-right-arrow bx-fade-right'></i>&nbsp;&nbsp;&nbsp;Click Here to Download as PDF / PDF பதிவிறக்கம் செய்ய இங்கே கிளிக் செய்யவும் &nbsp;&nbsp;&nbsp; <i class='bx bx-left-arrow bx-fade-left'></i> </button>
</center> 

</div>
</selection>
<!-- /container -->
<?php 
require('student_footer.php');
?>
<script type="text/javascript" src="./js/html2pdf.bundle.min.js"></script>
      <script>
         function generatePDF() {
          if(confirm('Are you sure to download the pdf file?')){
  // Choose the element that our invoice is rendered in.
  const element = document.getElementById("image-holder");
  // Choose the element and save the PDF for our user.
  // Generate the PDF.
        html2pdf().from(element).set({
          margin: 0.1,
           filename: '<?php echo "$regno"; ?>_F2287.pdf',
          html2canvas: { dpi: 100, letterRendering: true },
          jsPDF: {orientation: 'portrait', unit: 'in', format: 'A4', compressPDF: true}
        }).save();
      }
}
        </script>


<!-- <script>
//Add Input Fields
$(document).ready(function() {
    var max_fields = 10; //Maximum allowed input fields 
    var wrapper    = $(".wrapper"); //Input fields wrapper
    var add_button = $(".add_fields"); //Add button class or ID
    var x = 1; //Initial input field is set to 1
 
 //When user click on add input button
 $(add_button).click(function(e){
        e.preventDefault();
 //Check maximum allowed input fields
        if(x < max_fields){ 
            x++; //input field increment
 //add input field
            $(wrapper).append('<div><input type="file" class="form-control" name="script[]"  /> <a href="javascript:void(0);"  class="remove_field">Remove</a></div>');
        }
    });
 
    //when user click on remove button
    $(wrapper).on("click",".remove_field", function(e){ 
        e.preventDefault();
 $(this).parent('div').remove(); //remove inout field
 x--; //inout field decrement
    })
});
</script> -->

<script type="text/javascript">
  $(document).ready( function() {
     $(document).on('change', '.signature :file', function() {
     var input = $(this),
         label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
     input.trigger('fileselect', [label]);
     });

     $('.signature :file').on('fileselect', function(event, label) {
         
         var input = $(this).parents('.input-group').find(':text'),
             log = label;
         
         if( input.length ) {
             input.val(log);
         } else {
             if( log ) alert(log);
         }
     
     });
     function readURL(input) {
         if (input.files && input.files[0]) {
             var reader = new FileReader();
             
             reader.onload = function (e) {
                 $('#signatureshow').attr('src', e.target.result);
                
             }
             
             reader.readAsDataURL(input.files[0]);
         }
     }

     $("#signature").change(function(){
         var eid = $('#signatureshow');
         

     
         
             if(fileExtValidate(this,eid)) { // file extension validation function
             if(fileSizeValidate(this,eid)) { // file size validation function
                 //showImg(this);
                 readURL(this);
             }   
         } 
     });    
 });



  $("#fileUpload").on('change', function () {

     //Get count of selected files
     var countFiles = $(this)[0].files.length;
 var cgpa=$(".noofpages").text();
 if((countFiles+parseInt(cgpa))<=40){
     var imgPath = $(this)[0].value;
     var extn = imgPath.substring(imgPath.lastIndexOf('.') + 1).toLowerCase();
     var image_holder = $("#image-holder");
     // image_holder.empty();

     if (extn == "gif" || extn == "png" || extn == "jpg" || extn == "jpeg") {
         if (typeof (FileReader) != "undefined") {

             //loop for each file selected for uploaded.

             for (var i = 0; i < countFiles; i++) {
                    // $("<div/>", {
                                                    
                    //          "class":"single-div"
                             
                    //  }).appendTo(image_holder);
                 var reader = new FileReader();
                 reader.onload = function (e) {
                  $("<span/>", {
                                                    
                             "class":"close_icon icofont-close"
                             
                     }).appendTo(image_holder);
                     $("<img />", {
                         "src": e.target.result,
                             "class": "thumb-image",
                             "style":"width:730px;height:1100px;"
                             
                     }).appendTo(image_holder);
                     
                      $("<div/>", {
                                                    
                             "style":"page-break-after:always;"
                             
                     }).appendTo(image_holder);
                 }

                 image_holder.show();
                 reader.readAsDataURL($(this)[0].files[i]);
             }
             calco();

         } else {
             alert("This browser does not support FileReader.");
         }
     } else {
         alert("Pls select only images");
     }
   }else{
    alert("The total number of pages should not exceed 40.");
   }
 });

  $(document).on('click','.close_icon',function(){
    if(confirm('Are you sure to delete this page from your answer script?')){
    $(this).next('img').next('div').remove();
    $(this).next('img').remove();
    $(this).remove();
    calco();
    }
  });
  calco();
  function calco()
  {
    setTimeout(function(){


    var lln=$(".close_icon");
    // console.log(lln.length);
    $(".noofpages").html(lln.length);
  },500);
  }
//   $('.switch_button_progress').click(function(){
// $('.switch_button_progress').hide();
// $('.switch_button').show();
//   });
    $('.switch_button').click(function(){
// $('.switch_button_progress').show();
$('.switch_button').hide();
  });
</script>



<!-- <img src="./sample_pdf/7119817-01.jpg" width="730" height="1120">

           <div style='page-break-after:always'></div>

            <img src="./sample_pdf/7119817-01.jpg" width="730" height="1120">

           <div style='page-break-after:always'></div>

            <img src="./sample_pdf/7119817-01.jpg" width="730" height="1120">

           <div style='page-break-after:always'></div>

            <img src="./sample_pdf/7119817-01.jpg" width="730" height="1120">

           <div style='page-break-after:always'></div>

            <img src="./sample_pdf/7119817-01.jpg" width="730" height="1120">

           <div style='page-break-after:always'></div>

            <img src="./sample_pdf/7119817-01.jpg" width="730" height="1120">

           <div style='page-break-after:always'></div>  -->