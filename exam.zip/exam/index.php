<?php
       include 'header.php';
       ?>
              <section id="hero" class="d-flex align-items-center">

    <div class="container-fluid" data-aos="fade-up">
      <div class="row justify-content-center">
      	 
        <div class="col-xl-5 col-lg-6 pt-3 pt-lg-0 order-2 order-lg-1 d-flex flex-column justify-content-center">

          <h1 style="font-size: 22px; line-height: 30px">University Departments / <br> பல்கலைக்கழக துறைகள்  </h1><br><br>
          <h2 style="font-size: 15px;line-height: 30px">Online Examination System(April - 2021)/ஆன்லைன் தேர்வு அமைப்பு (ஏப்ரல் - 2021)</h2>
<br><br>
<!-- <div><marquee class="btn-get-started scrollto"  behavior=alternate scrollamount="8" onmouseover="this.stop();" onmouseout="this.start();"style="padding: 0px;">

          <strong>Mock Test - Phase I : 09.00 AM to 12.00 Noon | Phase II: 12.00 Noon to 03.00 PM</strong>

        </marquee></div> -->
          <div><a href="student_login.php" class="btn-get-started scrollto"><i class='bx bxs-like bx-fade-right'></i>&nbsp;&nbsp;&nbsp;<i class='bx bx-user'></i>Student Login /மாணவர் உள்நுழைவு</a></div>
        </div>
        <div class="col-xl-4 col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="150">
          <img src="assets/img/hero-img.png" class="img-fluid animated" alt="">
        </div>
      </div>
    </div>

  </section>
       <!-- <?php
       // include 'about.php';
       ?> -->
       <?php
       include 'footer.php';
       ?>