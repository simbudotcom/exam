<?php
//session_start();
error_reporting(0);
//require_once('config.php');
require('../common/index.php');
//require('student_functions.php');
require('student_header.php');
date_default_timezone_set('Asia/Kolkata');
$now=date('Y-m-d H:i:s');
$data=get_student_data($con, $_SESSION['UserData']['id']);
$hname=$data['name'];
$regno=$data['regno'];
$course_code=$data['course_code'];
$session_year=$data['session_year'];
$subid= $_GET['subid'];
$subject_code=base64_decode($subid); 
$count1=0;
$sql111 = "SELECT count(subject_code) as scount  from `subjects` where `subject_code`='$subject_code' and `session_year`='$session_year' limit 1"; 
                 $exe111 = mysqli_query($con,$sql111) or die(mysql_error());
              //$row1 = mysqli_fetch_array($exe1);
              //echo $sql1;
                 $row111 = mysqli_fetch_array($exe111);
                
                  $count1=$row111['scount'];
               

if($count1==0)
{
 echo ("<script language='JavaScript'>
          window.alert('Your URL was Wrong. Kindly reclick the examination answer script uploading button / தங்களது வலைத்தள முகவரி  தவறாக உள்ளது தயவுசெய்து மீண்டும் முயற்சிக்கவும் ');
          window.location.href='student_view_exam1.php';
       </script>"); 
}



if (!isset($_SESSION['UserData'])) {
    exit(header("location:student_main.php"));
}

$count=0;
$sql1 = "SELECT count(regno) as ucount from `uploads_scripts` where `regno`='$regno' and `subject_code`='$subject_code' limit 1"; 
                 $exe1 = mysqli_query($con,$sql1) or die(mysql_error());
              //$row1 = mysqli_fetch_array($exe1);
              //echo $sql1;
                 $row1 = mysqli_fetch_array($exe1);
                
                  $count=$row1['ucount'];
                

if($count>0)
{
 echo ("<script language='JavaScript'>
          window.alert('Already Uploaded Your Examination script. Thank You');
          window.location.href='student_view_status.php';
       </script>"); 
}
?>

<?php 
if(isset($_POST["step2_submit"]))
{
  sleep(5);
  $file_name=trim($course_code."_".$subject_code."_".$regno).".pdf";
  if(!s3_file_exists('alagappa-online-exam-reg-uploads', $file_name)):
    echo "<script type='text/javascript'>
          alert('Network Error: Your Examination script did not upload correctly. Please upload agian.');
          </script>";
  else:
  $sql = "INSERT INTO uploads_scripts(regno,course_code,subject_code,session_year,t_file,uploded_time)VALUES ('$regno','$course_code','$subject_code','$session_year','$file_name','$now')";
//echo $sql;
//die();
            if (mysqli_query($con, $sql)) {
               $message='Your Examination Script Successfullly Uploaded!...'.'Student Details: Reg. No: '.$regno.' Subject Code: '.$subject_code.' Thank You...';
               echo "<script type='text/javascript'>
                    alert('$message');
                    window.location.href='./student_view_status.php';
                    </script>" ;
              }
  endif;
}
?>

<style>
  .main-login{
    padding-top: 0px;
    width: 850px;
  }
  form#student_login_form123 {
       background-color: rgba(0, 123, 255, .25);
       padding: 50px;
      border-radius: 10px;

}
input#Email {
    margin-bottom: 24px;
}
button#button-main{
   margin-top: 24px;
   border: none;
}
h3.form-signin-heading{
  color: #8e33f6;
  font-weight: bold;  
}
</style>
<section class="page-section mb-0" style="min-height: 530px">
   <div class="container">  
  <br><br><br> <?php include 'stud_menu.php'; ?> 
     <br>
<center>
  <div class="table-responsive">
<div class="main-login">
      <form name="student_login_form" id="student_upload_form">
        <h3 class="form-signin-heading" style="font-size: 25px">Upload Your Answer Script / <br>விடைத்தாள் பதிவேற்றும் இடம் </h3>
<br>
         <label style="color: #012109;">Register Number / பதிவு எண்</label>
        <input type="text" name="regno" id="regno" class="form-control" value="<?php echo $regno; ?>" readonly="readonly"><br>

         <label style="color: #012109;">Name of the Student / மாணவரின் பெயர் </label>
        <input type="text" name="name" id="name" class="form-control" value="<?php echo $hname; ?>" readonly="readonly"> <br><br>
        <label style="color: #012109;">Choose Your Answer Script File / விடைத்தாளை தெரிவு செய்யவும் <br><span style="color: red">* Must be in .PDF file only / pdf மட்டுமே ஏற்றுக்கொள்ளப்படும் </span></label>
        <input type="file" name="uploadfile" id="uploadfile" class="form-control" required="required" accept="application/pdf"> 

        <div id="display_error" style="color: #FFFFFF!important;background-color: red; border: none;"></div>
        <br>
<input type="checkbox" class="forn-control" required="" name="confirmation" />
<label>Confirm submission / பதிவேற்றத்தை உறுதிசெய்க</label>
        <br>
        <span id="upload_progress" style="font-size: 26px;display: block;margin-bottom: 12px;color: red;"></span>
        <input class="btn btn-primary" type="submit" name="submit" value="Upload / பதிவேற்று">
       <!-- <button id="button-main" type="submit" name="submit" class="btn btn-lg btn-primary btn-block">Upload / பதிவேற்று</button> -->
      </form><br><br><br>

<form id="step2_form" method="POST">
  <input type="hidden" name="regno" id="regno" value="<?php echo $regno; ?>" />
  <input type="hidden" name="name" id="name" value="<?php echo $hname; ?>" />
  <input type="hidden" name="step2_submit" value="submit" />
</form>
<!-- /HTML Form -->
</div>
</div>
</center>

</div></section>   



<!-- /container -->
<?php 
require('student_footer.php');
?>
<link rel="stylesheet" href="./includes/DataTable/datatables.css" type="text/css">
    <link rel="stylesheet" href="./includes/DataTable/datatables.min.css" type="text/css">
    <script src="./includes/DataTable/datatables.js"></script> 
    <script src="./includes/DataTable/datatables.min.js"></script>

<script>
<?php $file_name=$course_code."_".$subject_code."_".$regno; ?>
var uploadUrl = "<?php echo getPresignedUrl('alagappa-online-exam-reg-uploads', trim($file_name) . '.pdf'); ?>";
var uploading = false;
jQuery(function($){
  $('#student_upload_form').on("submit", function(e){
    e.preventDefault();
    if(uploading){
      alert('A file is already being uploaded./தற்போது உங்களது PDF பதிவேற்றப்பட்டுக்கொண்டிருக்கிறது, காத்திருக்கவும்.');
      return;
    }
    const fileInput = $('#uploadfile', this);
    const fileToUpload = fileInput[0].files[0];
    if(fileToUpload == null){
      alert('Please select a file');
      return;
    }
    if(fileToUpload.type != 'application/pdf'){
      alert('Only PDF files are allowed. Please upload a PDF document.');
      return;
    }
    if(fileToUpload.size > 100 * 1024 * 1024){
      alert('File size must be less than 100MB / நீங்கள் தேர்வு செய்த PDF file 100MB க்கு குறைவாக இருக்க வேண்டும்.');
      return;
    }
    
    const xhr = new XMLHttpRequest();
    xhr.open('PUT', uploadUrl);

    xhr.upload.addEventListener("progress", function (e) {
      uploading = true;
        if (e.lengthComputable) {
            var percentage = (e.loaded / e.total) * 100;
            $('#upload_progress').text(parseInt(percentage) + '% uploaded (Do not press any Button).../பதிவேற்றப்படுகிறது (வேறு பொத்தானை அழுத்த வேண்டாம்)...');
        }
    });

    xhr.upload.addEventListener("load", function () {
      uploading = false;
      $('#upload_progress').text('File uploaded (Do not press any Button)./பதிவேற்றப்பட்டது (வேறு பொத்தானை அழுத்த வேண்டாம்). ');
      $('#step2_form')[0].submit();
    });

    xhr.setRequestHeader("Content-Type", fileToUpload.type);
    xhr.send(fileToUpload);
  })
});
</script>
<style>
@media only screen and (min-width:768px){
  .home_slider_left{
    width:22%;
    margin:0;
    padding-right:15px;
  }
  .home_slider{
    width:78%;
    margin:0;
  }
  .home_slider_right{
    width:22%;
    margin:0;
    padding-left:28px;
  }
}
</style>


