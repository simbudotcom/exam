<?php
/*Function to get users data*/
require_once('config.php');
function get_student_data($con, $id, $get_additional_info=false){
    if($get_additional_info){
        $q = "SELECT s.*, c.course_name as course_name FROM student s LEFT JOIN course c ON c.course_code=s.course_code WHERE s.regno='$id' LIMIT 1";
    }
    else{
        $q = "SELECT * FROM student WHERE regno='$id' LIMIT 1";
    }
    $result = mysqli_query($con, $q);
    if(mysqli_num_rows($result)==1){
        return mysqli_fetch_assoc($result);
    }else{
        return FALSE;
    }
}


function safe_input($con, $data1) {
  return htmlspecialchars(mysqli_real_escape_string($con, trim($data1)));
}

/*Function to set JSON output*/
function output($Return=array()){
    /*Set response header*/
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    /*Final JSON response*/
    exit(json_encode($Return));
}

?>
