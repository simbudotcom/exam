<?php
/*PHP Login and registration script Version 1.0, Created by Gautam, www.w3schools.in*/
error_reporting(0);
require_once('config.php');
$exam_date= $_GET['exam_date'];
//require('student_functions.php');
require('student_header.php');
?>
<section class="page-section mb-0" style="min-height: 530px">
   <div class="container">  
  <br><br> <?php include('stud_menu.php'); ?> 
     <br><br>

 <div class="row justify-content-center align-items-center">
    <div class="table_content table-responsive">

      <table border="0" class="table table-striped">
        <tr>
            
            <td width="300px">Name of the Candidate / மாணவரின் பெயர் </td>
            <td width="10px">:</td>
            <td width="500px"><?php print $row1['name']; ?></td>
        </tr>
    <?php
        $subject_code='';
        $session_year='';
                             $sql1 = "SELECT  * FROM subjects where exam_date=$exam_date order by subject_code asc group by subject_code"; 
                 $exe1 = mysqli_query($con,$sql1) or die(mysql_error());
                 //echo $sql1;
                 while($row1 = mysqli_fetch_array($exe1))
                {

                    $subject_code=$sql1['subject_code'];
                    $session_year=$sql1['session_year'];
                    $regno='';
                    $sql11 = "SELECT  * FROM student_online_data where subject_code=$subject_code and session_year=$session_year"; 
                 $exe11 = mysqli_query($con,$sql11) or die(mysql_error());
                 //echo $sql1;
                 while($row11 = mysqli_fetch_array($exe11))
                {

                    $regno=$sql11['regno'];
                   }
                   $centre_code='';
                   $sql11e = "SELECT  * FROM student_master where ENROLMENT=$regno limit 1"; 
                 $exe11e = mysqli_query($con,$sql11e) or die(mysql_error());
                 //echo $sql1;
                 $row11e = mysqli_fetch_array($exe11e))
                 $centre_code=$sql11e['regno'];
                 

                   $count=0
                   $sql111 = "SELECT  count(regno) as counter FROM uploads_scripts where regno!=$regno and subject_code!=$subject_code and session_year!=$session_year limit 1"; 
                 $exe111 = mysqli_query($con,$sql111) or die(mysql_error());
                 //echo $sql1;
                 $row111= mysqli_fetch_array($exe111);
                 $count=$row111['counter'];
                   
                 if($counter>0)
                 {
                    ?>
                    <tr>
            
            <td><?php print $regno; ?></td>
            <td><?php print $subject_code; ?></td>
            <td><?php print $session_year; ?></td>
             <td><?php print $centre_code; ?></td>
        </tr>
            <?php
                 }
         } 
 
   ?>
</table> 
</div></div>
</div></section>
<!-- /container -->
<?php 
require('student_footer.php');
?>
