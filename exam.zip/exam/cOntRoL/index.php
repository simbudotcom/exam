<?php
require('admin_header.php');
?>

<style>
	.main-login{
		
   
    height: 410px;
    width: 450px;
    margin-left: 350px;
	}
	form#login_form {
       background-color: transparent;
      border-radius: 10px;

}
input#Email {
    margin-bottom: 24px;
}
button#button-main{
	 margin-top: 24px;
	 background-color: #39840b;
   border: none;
}
h3.form-signin-heading{
	color: #059090;
	font-weight: bold;	
}
</style>

   <section class="banner-area1">
   <div class="container">   
    <br><br> <br><br><br><br> <br><br>
      <div id="introCarousel" class="carousel  slide carousel-fade" data-ride="carousel">


<!-- Login Form -->

<!-- HTML Form -->
<div class="main-login">
      <form action="submit.php" method="post" name="login_form" id="login_form" autocomplete="off">
        <h3 class="form-signin-heading">Admin Login</h3>

        <label for="Email" class="sr-only">User Name</label>
        <input type="text" name="Email" id="Email" class="form-control" placeholder="User Name" required autofocus><br>

        <label for="Password" class="sr-only">Password</label>
        <input type="password" name="Password" id="Password" class="form-control" placeholder="Password" required pattern=".{6,12}" title="6 to 12 characters.">

        <div id="display_error" class="alert alert-danger fade in" style="color: #FFFFFF!important;background-color: #112379; border: none;"></div><!-- Display Error Container -->

        <button id="button-main" type="submit" class="btn btn-lg btn-primary btn-block">Login</button>
      </form>
<!-- /HTML Form -->
</div>




    </div></div></section>


<?php require('admin_footer.php');?>