<?php
/*PHP Login and registration script Version 1.0, Created by Gautam, www.w3schools.in*/
error_reporting(0);

/*Check for authentication otherwise user will be redirects to main.php page.*/
if (!isset($_SESSION['UserData'])) {
    exit(header("location:main.php"));
}
require('admin_header.php');
?>
<?php
//echo '<pre>';
  // print_r(get_govt_user_data($con, $_SESSION['UserData']['user_id']));
//die();
$hname='';
$data=get_user_data($con, $_SESSION['UserData']['user_id']);
$hname=$data['email'];
$dept=$data['dept'];
$category=$data['category'];
//echo '</pre>';
//
if ($category!='admin') {
  
    exit(header("location:main.php"));
}
?>
    
<?php
               if(isset($_POST['submit2']))
                           {

                $regno=$con->real_escape_string($_POST['regno']);
                $dob=date('Y-m-d',strtotime($_POST['dob']));
                    
            

$sql = "UPDATE student SET `dob`='$dob' WHERE `regno`='$regno'";
//echo $sql;
//die();
            if (mysqli_query($con, $sql)) {
               $message='Student Details: Reg. No: '.$regno.' DOB: '.$dob.' Successfully Updated Thank You...';
               echo "<script type='text/javascript'>
                    alert('$message');
                    window.location.href='./login.php';
                    </script>" ;
              }  
          }
          ?>
<section class="page-section mb-0" style="min-height: 570px">
   <div class="container">   
    <br><br> <br><br><br><br> <br>
      <div id="introCarousel" class="carousel  slide carousel-fade" data-ride="carousel">
<!-- container -->


</div>
      <div class="container-fluid">
<div class="row">
   <div class="col-xl-12 col-lg-12">
    <a href="../../AlU_ExaM_Aff_Col/cOntRoL/login.php"><button class="btn btn-danger">For Affiliated Colleges</button></a>
  
       <a href="../../AlU_ExaM_ReG_DeP/cOntRoL/login.php"><button class="btn btn-danger">For Regular Departments</button></a>
    </div>        
</div><br><br>
          <!-- Content Row -->

  <div class="col-xl-12 col-lg-7">
              <div class="card shadow mb-4">
            
                <form name="myForm"  action="#" method="POST" onsubmit="return validateForm()" enctype="multipart/form-data">
    <table width="100%" style="background-color: #5bc0de;">
        <tr><th style="text-align: center;">Enter Register Number</th>
<td style="text-align: center;">
       <input type="text" name="regno" id="regno" class="form-control" placeholder="Enter Register Number"></td><td><button type="submit" name="submit" id="submit" value="" style="
    background: green;
    color: white;
    /* border: 10px; */
    border-radius: 5px;
    border-color: green;
    padding: 10px 20px 10px 20px;
">Search</button>&nbsp;&nbsp;<button type="reset" name="submit1" id="submit1" value="" style="
    background: red;
    color: white;
    /* border: 10px; */
    border-radius: 5px;
    border-color: red;
    padding: 10px 20px 10px 20px;
" >Reset</button></td></tr>

 </table>
</form>



              </div></div></div>


          <!-- Content Row -->

<?php
               if(isset($_POST['submit']))
                           {

                $regno=$con->real_escape_string($_POST['regno']);
                    
            ?>
            <?php
  $slno=1;
   $sql1 = "SELECT * from `student` Where `regno`='$regno' order by `id` asc";

//echo $sql1;
   
  $exe1 = mysqli_query($con,$sql1) or die(mysql_error());
              //$row1 = mysqli_fetch_array($exe1);
              //echo $sql1;
                 while($row1 = mysqli_fetch_array($exe1))
                {
                  $sname=$row1['name'];
                  $dob=$row1['dob'];
                  $regno=$row1['regno'];
                
?>

<form name="myForm"  action="#" method="POST" onsubmit="return validateForm()" enctype="multipart/form-data">
    <table width="100%">
        <tr><th style="text-align: left;">Register Number</th>
<td style="text-align: left;">
       <input type="text" name="regno" id="regno" class="form-control" value="<?php echo $regno; ?>" readonly="readonly" required="required"></td></tr>
        <tr><th style="text-align: left;">Name of the Student</th>
<td style="text-align: left;">
       <input type="text" name="name" id="name" class="form-control" value="<?php echo $sname; ?>" readonly="readonly" required="required"></td></tr>
        <tr><th style="text-align: left;">Date of Birth</th>
<td style="text-align: left;">
       <input type="text" data-inputmask-alias="dd-mm-yyyy" inputmode="numeric" data-inputmask-inputformat="dd-mm-yyyy" name="dob" id="dob" class="form-control" value="<?php echo date('d-m-Y',strtotime($dob)); ?>" required="required"></td></tr><tr>
       <td colspan="2" style="text-align: center;"><button type="submit" name="submit2" id="submit2" style="
    background: green;
    color: white;
    /* border: 10px; */
    border-radius: 5px;
    border-color: green;
    padding: 10px 20px 10px 20px;
">Update</button></td></tr>

 </table>
</form>

<?php 
} }
?>


          <!-- Content Row -->
         

        </div>
      </div>
    </div>
  </section>
  </body>
</html>
<?php
include('admin_footer.php');
//echo "hai";
?>
<link rel="stylesheet" href="./includes/DataTable/datatables.css" type="text/css">
    <link rel="stylesheet" href="./includes/DataTable/datatables.min.css" type="text/css">
    <script src="./includes/DataTable/datatables.js"></script> 
    <script src="./includes/DataTable/datatables.min.js"></script> 
<script>
/*$(document).ready( function () {
    $('#myTable').DataTable();
} );*/
$(document).ready(function() {
    var printCounter = 0;
 
    // Append a caption to the table before the DataTables initialisation
   // $('#view_stock').append('<caption style="caption-side: bottom">Stock List View.</caption>');
 
    $('#myTable').DataTable( {
        dom: 'Bfrtip',
        scrollX:'true',
        buttons: [
            'copy',
            {
                extend: 'excel',
                messageTop: ''
            },
            {
                extend: 'pdf',
                orientation:'landscape',
                messageBottom: null
            },
            {
                extend: 'print',
                messageTop: function () {
                    printCounter++;
 
                    if ( printCounter === 1 ) {
                        return 'This is the first time you have printed this document.';
                    }
                    else {
                        return 'You have printed this document '+printCounter+' times';
                    }
                },
                messageBottom: null
            }
        ]
    } );
} );
</script>

<style>
@media only screen and (min-width:768px){
  .home_slider_left{
    width:22%;
    margin:0;
    padding-right:15px;
  }
  .home_slider{
    width:78%;
    margin:0;
  }
  .home_slider_right{
    width:22%;
    margin:0;
    padding-left:28px;

  }
}
</style>

<script type="text/javascript">
  $("#dob").inputmask({
               "onincomplete": function () {
                   $(this).addClass('alert alert-danger');
                   $("#dob").val('');
                   $("#display_error").html('Enter Correct Date of Birth');
               },
               "oncomplete": function () {
                   $(this).removeClass('alert alert-danger');
                   $("#display_error").html('');
               }
           });
</script>



