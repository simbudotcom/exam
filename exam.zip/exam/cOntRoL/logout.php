<?php session_start(); /* Starts the session */
session_destroy();
$gname='';
$aname=''; /* Destroy started session */
header("location:index.php");
exit;
?>
