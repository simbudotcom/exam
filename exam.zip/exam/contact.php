<?php
       include 'header.php';
       ?>
          <section id="about" class="about" style="padding-top: 120px;min-height: 580px">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 order-1 order-lg-2" data-aos="zoom-in" data-aos-delay="150">
           <p class="font-italic">
            
            </p>
            <ul>
              <li><i class="icofont-check-circled"></i> </li>
              <li><i class="icofont-check-circled"></i>  </li>
              <li><i class="icofont-check-circled"></i>  </li>
            </ul>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content" data-aos="fade-right">
            <h4>CONTACT/தொடர்பு</h4>
            <p class="font-italic">
           
            </p>
            <ul>
              <li><i class="icofont-check-circled"></i> </li>
              <li><i class="icofont-check-circled"></i>  </li>
              <li><i class="icofont-check-circled"></i>  </li>
            </ul>
           <!--  <a href="#" class="read-more">Read More <i class="icofont-long-arrow-right"></i></a> -->

          </div>
        </div>
<br><br><br><br>
      </div></section>
   <?php
       include 'footer.php';
       ?>