<?php
/*PHP Login and registration script Version 1.0, Created by Gautam, www.w3schools.in*/
error_reporting(0);
//require_once('config.php');
//require('student_functions.php');
require('student_header.php');
/*Check for authentication otherwise user will be redirects to main.php page.*/
if (!isset($_SESSION['UserData'])) {
    exit(header("location:student_main.php"));
}


?>
<!-- <meta http-equiv="refresh" content="5" > -->
<?php
//echo '<pre>';
date_default_timezone_set('Asia/Kolkata');
$data=get_student_data($con, $_SESSION['UserData']['id'], true);
$hname=$data['name'];
$regno=$data['regno'];
$course_code=$data['course_code'];
$course_name = $data['course_name'];
//echo '</pre>';
//

if ($hname=='') {
  
    exit(header("location:logout.php"));
}
if ($user_type=='admin') {
  
    exit(header("location:index.php"));
}

?>
<section class="page-section mb-0" style="min-height: 530px">
   <div class="container">  
  <br><br> <?php include('stud_menu.php'); ?> 
     <br><br>

 <div class="row justify-content-center align-items-center">
    
        
      <div class="table_content table-responsive">

      <table border="0" class="table table-striped">
        <tr>
            
            <td width="300px">Name of the Candidate / மாணவரின் பெயர் </td>
            <td width="10px">:</td>
            <td width="500px"><?php print $hname; ?></td>
        </tr>
        <tr>
            
            <td width="300px">Register Number / பதிவு எண் </td>
            <td>:</td> 
            <td width="500px"><?php print $regno; ?> </td>
        </tr>
        <tr>
           
            <td width="300px">Course Code / பாடநெறி குறியீடு  </td>
            <td>:</td>
            <td width="500px"><?php  print $course_code; ?></td>
        </tr>
        <tr>
           

               
            <td width="300px">Name of the Programme / பட்டத்தின் பெயர் </td>
            <td>:</td>
             <td width="500px"><?php 
                 
                 print $course_name; 
                 ?>
             </td>
         </tr>
  


    

</table><br><br> <br><br> <br><br> 
</div></div>
</div></section>
<!-- /container -->
<?php 
require('student_footer.php');
?>
