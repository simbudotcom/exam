<?php
/*PHP Login and registration script Version 1.0, Created by Gautam, www.w3schools.in*/
error_reporting(0);
//require('config.php');

require_once('student_header.php');
/*Check for authentication otherwise user will be redirects to main.php page.*/
if (!isset($_SESSION['UserData'])) {
    exit(header("location:student_main.php"));
}


?>
<?php
//echo '<pre>';
date_default_timezone_set('Asia/Kolkata');
$data=get_student_data($con, $_SESSION['UserData']['id']);
$hname=$data['name'];
$regno=$data['regno'];
$course_code=$data['course_code'];
//echo '</pre>';
//
if ($hname=='') {
  
    exit(header("location:logout.php"));
}
if ($user_type=='admin') {
  
    exit(header("location:index.php"));
}

?>
<section class="page-section mb-0" style="min-height: 530px">
   <div class="container">  
  <br><br> <?php include 'stud_menu.php'; ?> 
     <br><br>

 <div class="row justify-content-center align-items-center">
           
      <div class="table_content table-responsive">

      <table border="0" class="table table-striped">
        <tr>
            
          
            <td width="500px"><a href="https://alu-questionpapers-apr-2021.s3.ap-south-1.amazonaws.com/reg/annexure1.pdf" target="_blank">Annexure 1 / பின்னிணைப்பு  1</td>
        </tr>
        <tr>
            
           
             <td width="500px"><a href="https://alu-questionpapers-apr-2021.s3.ap-south-1.amazonaws.com/reg/annexure2.pdf" target="_blank"> Annexure 2 / பின்னிணைப்பு  2</td>
        </tr>
       
  


    

  
</table><br><br> <br><br> <br><br> 
</div></div>
</div></section>
<!-- /container -->
<?php 
require('student_footer.php');
?>
