<?php
/*PHP Login and registration script Version 1.0, Created by Gautam, www.w3schools.in*/
error_reporting(0);
require('config.php');

require('super_functions.php');

/*Check for authentication otherwise user will be redirects to main.php page.*/
if (!isset($_SESSION['UserData'])) {
    exit(header("location:super_main.php"));
}

require('super_header.php');
?>
<?php
//echo '<pre>';
  // print_r(get_govt_user_data($con, $_SESSION['UserData']['user_id']));
//die();
$hname='';
$data=get_super_user_data($con, $_SESSION['UserData']['user_id']);
$hname=$data['email'];
$dept=$data['dept'];
$category=$data['category'];
//echo '</pre>';
//
if ($hname=='') {
  
    exit(header("location:logout.php"));
}
if ($category!='admin') {
  
    exit(header("location:super_main.php"));
}
?>
  <section class="page-section mb-0" style="min-height: 550px">
   <div class="container">   
   <br>   <br><br> <br><br><br>
<center><button class="btn btn-primary"> B.Ed., Questions </button></center><br>
 <table cellpadding="0"cellspacing="0" border="1"  id="myTable"  style="color:black; width:100%" >
<thead>
<tr class="new_data_tab">
<th class="text-center">Sl. No.</th>
<th class="text-center">Question</th>
<th class="text-center">Correct Answer</th>
<th class="text-center">Topic</th>
</tr>
</thead><tbody>


    <?php
          $slno=1;      
               $sql1 = "SELECT * from `bed_questions` order by que_id asc"; 
                 $exe1 = mysqli_query($con,$sql1) or die(mysql_error());
                 //echo $sql1;
                 while($row1 = mysqli_fetch_array($exe1))
                {
                   
        ?>
      <tr class="odd">
            
            <td><?php echo $slno; ?></td>
            <td><img src="<?php $row1['que_desc']; ?>"></td>
           <td><?php $row1['true_ans']; ?></td>
           <td><?php $row1['rand_name']; ?></td>
        </tr>

    

  <?php
   } $slno=$slno+1;


        unset($_SESSION[tid]);

   ?>
</table>
</div></div>
</div></section>
<!-- /container -->
<?php 
require('student_footer.php');
?>
<link rel="stylesheet" href="./includes/DataTable/datatables.css" type="text/css">
    <link rel="stylesheet" href="./includes/DataTable/datatables.min.css" type="text/css">
    <script src="./includes/DataTable/datatables.js"></script> 
    <script src="./includes/DataTable/datatables.min.js"></script>

<script>

$(document).ready(function() {
    var printCounter = 0;
 
    // Append a caption to the table before the DataTables initialisation
   // $('#view_stock').append('<caption style="caption-side: bottom">Stock List View.</caption>');
 
    $('#myTable').DataTable( {
        dom: 'lBfrtip',
        buttons: [
            
        ]
    } );
} );
</script>
<style>
@media only screen and (min-width:768px){
  .home_slider_left{
    width:22%;
    margin:0;
    padding-right:15px;
  }
  .home_slider{
    width:78%;
    margin:0;
  }
  .home_slider_right{
    width:22%;
    margin:0;
    padding-left:28px;

  }
}
</style>