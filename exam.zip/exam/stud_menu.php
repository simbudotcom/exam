<br><br><div align="right" style="color: #17a2b8; padding-top: 10px;">Welcome to ALU : Mr/Ms. <?php print $hname; ?>. <a href="logout.php"><img src="assets/img/logout.png" width="20px" height="20px" title="Press for Logout" alt="Logout"></a></div>

<div align="left" style="border: green;border-radius: 5px;color: #ffffff!important;padding-top: 10px;padding-bottom: 10px; padding-left: 20px;">
<a class="btn btn btn-primary" style="min-width: 200px;text-align: left;margin-top: 10px;" href="student_login.php" role="button">1. Student &nbsp;&nbsp; Home&nbsp;&nbsp; /  &nbsp;&nbsp;&nbsp; மாணவர் &nbsp;&nbsp; முகப்பு  </a>
 <a class="btn btn btn-primary" style="min-width: 200px;text-align: left;margin-top: 10px;" href="hall_ticket.php" role="button">2. View Hall Ticket / அனுமதிச் சீட்டு  </a>

  <a class="btn btn btn-primary" style="min-width: 200px;text-align: left;margin-top: 10px;" href="student_annexure.php" role="button">3. View Annexures / பின்னிணைப்புகள்  </a>
<!-- 

<a class="btn btn btn-primary" style="min-width: 200px;text-align: left;margin-top: 10px;" href="student_view_exam_mock.php" role="button">4. Mock Question Paper Download / மாதிரி வினாத்தாள் பதிவிறக்கம்  </a>
 <a class="btn btn btn-primary" style="min-width: 200px;text-align: left;margin-top: 10px;" href="jpgtopdf.php" role="button">5. Convert JPG TO PDF / JPG TO PDF மாற்ற</a>
<a class="btn btn btn-primary" style="min-width: 200px;text-align: left;margin-top: 10px;" href="student_view_exam1_mock.php" role="button">6. Mock Answer Script Upload / மாதிரி விடைத்தாள் பதிவேற்றம்  </a> 
<a class="btn btn btn-primary" style="min-width: 200px;text-align: left;margin-top: 10px;" href="student_view_status_mock.php" role="button">7. Mock Answer Script Upload Status / மாதிரி விடைத்தாள் பதிவேற்றம் செய்ததற்கான நிலை</a> 
-->


<a class="btn btn btn-primary" style="min-width: 200px;text-align: left;margin-top: 10px;" href="student_view_exam.php" role="button">4. Question Paper Download / வினாத்தாள் பதிவிறக்கம்  </a>
 <a class="btn btn btn-primary" style="min-width: 200px;text-align: left;margin-top: 10px;" href="jpgtopdf.php" role="button">5. Convert JPG TO PDF / JPG TO PDF மாற்ற</a>
<a class="btn btn btn-primary" style="min-width: 200px;text-align: left;margin-top: 10px;" href="student_view_exam1.php" role="button">6. Answer Script Upload / விடைத்தாள் பதிவேற்றம்  </a> 

<a class="btn btn btn-primary" style="min-width: 200px;text-align: left;margin-top: 10px;" href="student_view_status.php" role="button">7. Answer Script(s) Upload Status / விடைத்தாள்(கள்) பதிவேற்றம் செய்ததற்கான நிலை</a> 



</div>

