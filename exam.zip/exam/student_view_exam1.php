<?php
/*PHP Login and registration script Version 1.0, Created by Gautam, www.w3schools.in*/
error_reporting(0);
//require_once('config.php');

// require('student_functions.php');
require_once('student_header.php');
/*Check for authentication otherwise user will be redirects to main.php page.*/
if (!isset($_SESSION['UserData'])) {
    exit(header("location:student_main.php"));
}


?>
<meta http-equiv="refresh" content="300" >
<?php
//echo '<pre>';
date_default_timezone_set('Asia/Kolkata');
$data=get_student_data($con, $_SESSION['UserData']['id']);
$hname=$data['name'];
$regno=$data['regno'];
$course_code=$data['course_code'];
$session_year=$data['session_year'];
//echo '</pre>';
//
if ($hname=='') {
  
    exit(header("location:logout.php"));
}
if ($user_type=='admin') {
  
    exit(header("location:index.php"));
}

?>
<section class="page-section mb-0" style="min-height: 530px">
   <div class="container">  
  <br><br><br> <?php include 'stud_menu.php'; ?> 
     <br>

 <center><h3 style="color: red"> Answer Script Upload / விடைத்தாள் பதிவேற்றம் </h3></center>
  <div class="table_content table-responsive">
 <table cellpadding="0"cellspacing="0" border="1"  id="myTable"  style="color:black; width:100%" >
<thead>
<tr class="new_data_tab">
<th class="text-center">Sl. No / <br>வ. எண் </th>
<th class="text-center">Subject/ Course Code /<br> பாடக்  குறியீடு </th>
<th class="text-center">Subject/ Course Name /<br>பாடத்தின்  பெயர் </th>
<th class="text-center">Date and Time /<br>தேதி மற்றும் நேரம் </th>
<th class="text-center">Exam Status /<br>தேர்வின் நிலை  </th>
<th class="text-center">Answer Script Upload <br>விடைத்தாள் பதிவேற்றம்</th>
</tr>
</thead><tbody>


    <?php
   $slno=1; 
   date_default_timezone_set('Asia/Kolkata'); 
   $curr_date_f=date('Y-m-d 00:00:00'); 
   $curr_date_t=date('Y-m-d 23:59:59');   
    $sql1 = "SELECT * FROM `student_online_data` son INNER JOIN `subjects` s ON son.regno='$regno' AND s.session_year='$session_year' AND s.subject_code=son.subject_code AND s.exam_date BETWEEN '$curr_date_f' AND '$curr_date_t' GROUP BY son.subject_code limit 2"; 
 $exe1 = mysqli_query($con,$sql1);
                 while($row1 = mysqli_fetch_array($exe1))
                {
                
                   
         $subject_code=$row1['subject_code'];
        $subject_name=$row1['subject_name'];
        $exam_date=$row1['exam_date'];
        $question_date=date('Y-m-d H:i:s', strtotime('-60 minutes', strtotime($exam_date)));
        $exam_date1=date('Y-m-d H:i:s', strtotime('180 minutes', strtotime($exam_date)));
         $exam_date2=date('Y-m-d H:i:s', strtotime('180 minutes', strtotime($exam_date)));
          $exam_finish_date=date('Y-m-d H:i:s', strtotime('60 minutes', strtotime($exam_date2)));
          $exam_finish_date1=date('Y-m-d H:i:s', strtotime('630 minutes', strtotime($exam_date2)));
?>
      <tr class="odd">
            
            <td><?php print $slno;?></td>
             <td><?php print $subject_code;?></td>
              <td><?php print $subject_name;?></td>
            <td><?php date_default_timezone_set('Asia/Kolkata'); $cur_date=date('Y-m-d H:i:s'); $date1=date('d-m-Y h:i:sa', strtotime($exam_date)); print $date1; ?>-<?php $date2=date('h:i:sa', strtotime($exam_date2)); print $date2; ?></td>

              <td><?php if($cur_date<$question_date){ ?><b style="color: green">Will be Conducted / நடைபெறவுள்ளது </b> <?php } 
              else if($cur_date>$question_date && $cur_date<$exam_finish_date) { ?><b style="color: blue">On Going / நடைபெற்றுக்கொண்டுள்ளது </b> <?php }
               else { ?><b style="color: red">Completed / நிறைவுபெற்றது </b><?php } ?></td>

            

             <td><?php if($cur_date<$exam_date){ ?><button class="btn btn-success" type="button">You have to wait till <?php  date_default_timezone_set('Asia/Kolkata'); $cur_date=date('Y-m-d H:i:s'); $ans_date1=date('d-m-Y h:i:sa', strtotime($exam_date)); print $ans_date1; ?> / நீங்கள் <?php print $ans_date1; ?> மணி  வரை காத்திருக்கவும்   </button> <?php } 
            else if($cur_date>$exam_date && $cur_date<$exam_finish_date1) { ?> <a href="up_script.php?subid=<?php  $subject_code1=base64_encode($subject_code); echo $subject_code1; ?>"><button class="btn btn-primary">Click Here to Upload your Answer Script / விடைத்தாள் பதிவேற்றம் செய்ய இங்கே கிளிக் செய்யவும் </button></a><?php } 
              else { ?><button class="btn btn-danger" type="button">Answer Script Uploading Time Expired / விடைத்தாள் பதிவேற்றம் செய்வதற்கான கால அவகாசம் நிறைவுபெற்றுவிட்டது   </button><?php } ?></td>
               </tr>

    

  <?php
    $slno=$slno+1;

 }

   ?></tbody>
</table></table>
</div></div><br>
</div></section>
<!-- /container -->
<?php 
require('student_footer.php');
?>
<link rel="stylesheet" href="./includes/DataTable/datatables.css" type="text/css">
    <link rel="stylesheet" href="./includes/DataTable/datatables.min.css" type="text/css">
    <script src="./includes/DataTable/datatables.js"></script> 
    <script src="./includes/DataTable/datatables.min.js"></script>

<script>

$(document).ready(function() {
    var printCounter = 0;
 
    // Append a caption to the table before the DataTables initialisation
   // $('#view_stock').append('<caption style="caption-side: bottom">Stock List View.</caption>');
 
    $('#myTable').DataTable( {
        dom: 'lBfrtip',
        "bPaginate": false,
    "bLengthChange": false,
    "bFilter": true,
    "bInfo": false,
        buttons: [
            
        ]
    } );
} );
</script>
<style>
@media only screen and (min-width:768px){
  .home_slider_left{
    width:22%;
    margin:0;
    padding-right:15px;
  }
  .home_slider{
    width:78%;
    margin:0;
  }
  .home_slider_right{
    width:22%;
    margin:0;
    padding-left:28px;

  }
}
</style>
