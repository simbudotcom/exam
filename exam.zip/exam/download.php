<?php
/*PHP Login and registration script Version 1.0, Created by Gautam, www.w3schools.in*/
error_reporting(0);
require_once('config.php');
require_once('student_functions.php');
$data=get_student_data($con, $_SESSION['UserData']['id']);
$regno=$data['regno'];
recordEvent('question_paper_download', $regno);
$url = urldecode($_GET['url']);
header('Location: '.$url);